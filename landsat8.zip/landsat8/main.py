import numpy as np
import cv2
from array import *
import os

import tkinter as tk
from tkinter import *
from tkinter import filedialog as fd
from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox

from osgeo import gdal, osr

'Параметры монитора'
screen_width = 2560
screen_height = 1440
screen_width_center = 1280
screen_height_center = 720
image_width = 512
image_left = (screen_width - 4 * image_width) // 2

root = Tk()
root.title(" * * * ")
root.geometry('550x750+600+200')
root.configure(width=500, height=300, bg="Grey")

height = 512
width = 512
imageR = np.zeros((height, width, 1), np.uint8)
imageG = np.zeros((height, width, 1), np.uint8)
imageB = np.zeros((height, width, 1), np.uint8)
imagetv = np.zeros((height, width, 3), np.uint8)

findfire = np.zeros((height, width, 1), np.uint8)

namesimg = []  # Массив названий файлов пакета

namessorted = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11']  # Сортированный массив названий файлов
namestomake = ['0', '1', '2', '3']  # Массив названий файлов для сборки цветного изображения

firepoints = []  # Массив лабиринта

def qExit():
	cv2.destroyAllWindows()
	root.destroy()


def mouse_event(event, x, y, flags, param):
	output = 0
	if event == cv2.EVENT_LBUTTONDOWN:
		print('--------- Mouse DOWN click LB ---------')
		ds = gdal.Open('.\\images\\' + combo.get() + '\\' + namessorted[1])
		old_cs = osr.SpatialReference()
		old_cs.ImportFromWkt(ds.GetProjectionRef())

		# create the new coordinate system
		wgs84_wkt = """
    GEOGCS["WGS 84",
    	DATUM["WGS_1984",
    		SPHEROID["WGS 84",6378137,298.257223563,
    			AUTHORITY["EPSG","7030"]],
    		AUTHORITY["EPSG","6326"]],
    	PRIMEM["Greenwich",0,
    		AUTHORITY["EPSG","8901"]],
    	UNIT["degree",0.01745329251994328,
    		AUTHORITY["EPSG","9122"]],
    	AUTHORITY["EPSG","4326"]]"""
		new_cs = osr.SpatialReference()
		new_cs.ImportFromWkt(wgs84_wkt)

		# create a transform object to convert between coordinate systems
		transform = osr.CoordinateTransformation(old_cs, new_cs)

		# print(ds)
		wds = ds.RasterXSize
		hds = ds.RasterYSize
		print(wds)
		print(hds)
		gt = ds.GetGeoTransform()
		print(gt)
		px = gt[0] + x * wds / 1000
		py = gt[3] + y * hds / 1000
		latlong = transform.TransformPoint(px, py)
		print(latlong)

		messagebox.showinfo("Широта и долгота", latlong)

	return output


def qMakeImg():
	print('qMakeImg')
	i = 1

	if ichB1.get() == 1:
		print('.\\images\\' + combo.get() + '\\' + namessorted[1])
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[1]
		i+=1

	if ichB2.get() == 1:
		print('.\\images\\' + combo.get() + '\\' + namessorted[2])
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[2]
		i+=1

	if ichB3.get() == 1:
		print('.\\images\\' + combo.get() + '\\' + namessorted[3])
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[3]
		i+=1

	if ichB4.get() == 1 and i < 4:
		print('.\\images\\' + combo.get() + '\\' + namessorted[4])
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[4]
		i+=1

	if ichB5.get() == 1 and i < 4:
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[5]
		cname = 'Ближний ИК (B5)'
		i+=1

	if ichB6.get() == 1 and i < 4:
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[6]
		cname = 'Коротковолновой ИК1 (B6)'
		i+=1

	if ichB7.get() == 1 and i < 4:
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[7]
		cname = 'Коротковолновой ИК2 (B7)'
		i+=1

	if ichB8.get() == 1 and i < 4:
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[8]
		i+=1

	if ichB9.get() == 1 and i < 4:
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[9]
		i+=1

	if ichB10.get() == 1 and i < 4:
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[10]
		cname = 'Тепловой 1 (B10)'
		i+=1

	if ichB11.get() == 1 and i < 4:
		namestomake[i] = '.\\images\\' + combo.get() + '\\' + namessorted[11]
		cname = 'Тепловой 2 (B11)'
		i+=1

	print(namestomake)

	file_R = namestomake[3]
	file_G = namestomake[2]
	file_B = namestomake[1]

	'Исходное изображение'
	imageR = cv2.imread(file_R, 0)
	imageG = cv2.imread(file_G, 0)
	imageB = cv2.imread(file_B, 0)

	clahe = cv2.createCLAHE(clipLimit=15.0, tileGridSize=(8, 8))
	imageR = clahe.apply(imageR)
	imageG = clahe.apply(imageG)
	imageB = clahe.apply(imageB)

	imageR = cv2.resize(imageR, (1000, 1000))
	imageG = cv2.resize(imageG, (1000, 1000))
	imageB = cv2.resize(imageB, (1000, 1000))
	global imagetv
	imagetv = cv2.resize(imagetv, (1000, 1000))

	imagetv[:,:,0] = imageR
	imagetv[:,:,1] = imageG
	imagetv[:,:,2] = imageB

	print(len(firepoints))
	for ii in range(len(firepoints)):
		imagetv = cv2.circle(imagetv, firepoints[ii], 10, (0, 0, 255), 1)

	cv2.imshow('TV', imagetv)
	cv2.moveWindow('TV', image_left + image_width * 2, 0)

	cv2.setMouseCallback('TV', mouse_event)

	messagebox.showinfo("Термически активные пиксели", 'Термически активные пиксели \n в канале \"%(names)s\": %(tp)s' % {"names" : cname, "tp" : len(firepoints)})

def qOpenPacket():
	global namesimg
	print('qOpenPacket')
	namesimg.clear()

	namesimg = [ f for f in os.listdir(".\\images" + "\\" + combo.get()) if f.endswith(".TIF") ]
	print(namesimg)
	for ii in range(len(namesimg)):
		print(namesimg[ii])
		fvalues = namesimg[ii].split('_')
		if fvalues[7] == 'B1.TIF':
			chB1.grid();
			namessorted[1] = namesimg[ii]
		if fvalues[7] == 'B2.TIF':
			chB2.grid();
			namessorted[2] = namesimg[ii]
		if fvalues[7] == 'B3.TIF':
			chB3.grid();
			namessorted[3] = namesimg[ii]
		if fvalues[7] == 'B4.TIF':
			chB4.grid();
			namessorted[4] = namesimg[ii]
		if fvalues[7] == 'B5.TIF':
			chB5.grid();
			namessorted[5] = namesimg[ii]
		if fvalues[7] == 'B6.TIF':
			chB6.grid();
			namessorted[6] = namesimg[ii]
		if fvalues[7] == 'B7.TIF':
			chB7.grid();
			namessorted[7] = namesimg[ii]
		if fvalues[7] == 'B8.TIF':
			chB8.grid();
			namessorted[8] = namesimg[ii]
		if fvalues[7] == 'B9.TIF':
			chB9.grid();
			namessorted[9] = namesimg[ii]
		if fvalues[7] == 'B10.TIF':
			chB10.grid();
			namessorted[10] = namesimg[ii]
		if fvalues[7] == 'B11.TIF':
			chB11.grid();
			namessorted[11] = namesimg[ii]


def get_b1(_):
	global image_left
	global image_width
	global screen_height_center
	print('.\\images\\'+combo.get()+'\\'+namessorted[1])
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[1]
	imageR = cv2.imread(file_R, 0)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('Violet', imageR)
	cv2.moveWindow('Violet', 0, 0)


def get_b2(_):
	global image_left
	global image_width
	global screen_height_center
	print('.\\images\\'+combo.get()+'\\'+namessorted[2])
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[2]
	imageR = cv2.imread(file_R, 0)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('Blue', imageR)
	cv2.moveWindow('Blue', 0, 0)


def get_b3(_):
	global image_left
	global image_width
	global screen_height_center
	print('.\\images\\'+combo.get()+'\\'+namessorted[3])
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[3]
	imageR = cv2.imread(file_R, 0)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('Green', imageR)
	cv2.moveWindow('Green', 0, 0)


def get_b4(_):
	global image_left
	global image_width
	global screen_height_center
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[4]
	imageR = cv2.imread(file_R, 0)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('Red', imageR)
	cv2.moveWindow('Red', 0, 0)


def get_b5(_):
	global image_left
	global image_width
	global screen_height_center
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[5]
	# Загрузка изображения
	imageR = cv2.imread(file_R, 0)
	# Расчет коэффициентов масштабирования
	ratioh = 1000/imageR.shape[0]
	ratiow = 1000/imageR.shape[1]
	# Поиск горячих пикселей
	result = np.where(imageR = [255])
	# Запись координат точек пожара
	firepoints.clear()
	for ii in range(len(result[0])):
		firepoints.append( (round(result[1][ii]*ratioh), round(result[0][ii]*ratiow)) )
	# Преобразование изображения для отображения на экране
	print(firepoints)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('NIR', imageR)
	cv2.moveWindow('NIR', 0, 0)


def get_b6(_):
	global image_left
	global image_width
	global screen_height_center
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[6]
	# Загрузка изображения
	imageR = cv2.imread(file_R, 0)
	# Расчет коэффициентов масштабирования
	ratioh = 1000 / imageR.shape[0]
	ratiow = 1000 / imageR.shape[1]
	# Поиск горячих пикселей
	result = np.where(imageR >= [250])
	# Запись координат точек пожара
	firepoints.clear()
	for ii in range(len(result[0])):
		firepoints.append((round(result[1][ii] * ratioh), round(result[0][ii] * ratiow)))
	print(firepoints)
	# Преобразование изображения для отображения на экране
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('SWIR 1', imageR)
	cv2.moveWindow('SWIR 1', 0, 0)


def get_b7(_):
	global image_left
	global image_width
	global screen_height_center
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[7]
	# Загрузка изображения
	imageR = cv2.imread(file_R, 0)
	# Расчет коэффициентов масштабирования
	ratioh = 1000/imageR.shape[0]
	ratiow = 1000/imageR.shape[1]
	# Поиск горячих пикселей
	result = np.where(imageR >= [250])
	# Запись координат точек пожара
	firepoints.clear()
	for ii in range(len(result[0])):
		firepoints.append( (round(result[1][ii]*ratioh), round(result[0][ii]*ratiow)) )
	print(firepoints)
	# Преобразование изображения для отображения на экране
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('SWIR 2', imageR)
	cv2.moveWindow('SWIR 2', 0, 0)


def get_b8(_):
	global image_left
	global image_width
	global screen_height_center
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[8]
	imageR = cv2.imread(file_R, 0)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('PAN', imageR)
	cv2.moveWindow('PAN', 0, 0)


def get_b9(_):
	global image_left
	global image_width
	global screen_height_center
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[9]
	imageR = cv2.imread(file_R, 0)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('Clouds', imageR)
	cv2.moveWindow('Clouds', 0, 0)


def get_b10(_):
	global image_left
	global image_width
	global screen_height_center
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[10]
	imageR = cv2.imread(file_R, 0)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('TIRS 1', imageR)
	cv2.moveWindow('TIRS 1', 0, 0)
	# Сбор цветов окружающих пикселей'
	firepoints.clear()
	imageR = cv2.cvtColor(imageR, cv2.CV_8U)
	for x in range(imageR.shape[0] - 1):
		for y in range(imageR.shape[1] - 1):
			color_ul = imageR[x - 1][y - 1]
			if (color_ul[0]>250):
				print(color_ul)
				firepoints.append((x,y))

def get_b11(_):
	global image_left
	global image_width
	global screen_height_center
	file_R = '.\\images\\'+combo.get()+'\\'+namessorted[11]
	imageR = cv2.imread(file_R, 0)
	imageR = cv2.resize(imageR, (500, 500))
	cv2.imshow('TIRS 2', imageR)
	cv2.moveWindow('TIRS 2', 0, 0)


##########################################################

ichB1 = IntVar()
ichB2 = IntVar()
ichB3 = IntVar()
ichB4 = IntVar()
ichB5 = IntVar()
ichB6 = IntVar()
ichB7 = IntVar()
ichB8 = IntVar()
ichB9 = IntVar()
ichB10 = IntVar()
ichB11 = IntVar()

# Создание кнопок и полей ввода
label0= Label(root, text=" Landsat 8 ", bg="Black", fg="#F9FAE9", font=("Times", 30))
label0.grid(row=0, column=0)


buttoncolor="#49D810"
buttonfg = "black"
button0 = Button(root,activebackground="red", text="Выход",bd=8, bg="#FF0000", fg="#EEEEF1", width=25, font=("Times", 12),command=qExit)
button0.grid(row=11, column=0, padx=10, pady=10)

# Создание списка пакетов изображений
combo = Combobox(root, font=("Times", 12), width=25)
# combo.current(0)  # установить вариант по умолчанию
combo.grid(row=0, column=1)

button25 = Button(root, activebackground="green", text="Открыть пакет", bd=8, bg=buttoncolor, fg=buttonfg, width =25, font=("Times", 12),command=qOpenPacket)
button25.grid(row=1, column=0, padx=10, pady=10)

satimg = []  # Массив пакетов
for filename in os.listdir(".\\images",):
	if os.path.isdir(".\\images\\"+filename):
		satimg.append(filename)

combo['values'] = satimg
combo.current(0)  # установить вариант по умолчанию

button21 = Button(root, activebackground="green", text="Собрать изображение", bd=8, bg=buttoncolor, fg=buttonfg, width =25, font=("Times", 12),command=qMakeImg)
button21.grid(row=4, column=0, padx=10, pady=10)

chB1 = Checkbutton(root, text='Дымка (B1)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB1)
chB1.grid(column=1, row=1, padx=10, pady=10)
chB2 = Checkbutton(root, text='Синий (B2)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB2)
chB2.grid(column=1, row=2, padx=10, pady=10)
chB3 = Checkbutton(root, text='Зеленый (B3)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB3)
chB3.grid(column=1, row=3, padx=10, pady=10)
chB4 = Checkbutton(root, text='Красный (B4)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB4)
chB4.grid(column=1, row=4, padx=10, pady=10)
chB5 = Checkbutton(root, text='Ближний ИК (B5)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB5)
chB5.grid(column=1, row=5, padx=10, pady=10)
chB6 = Checkbutton(root, text='Коротковолновой ИК1 (B6)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB6)
chB6.grid(column=1, row=6, padx=10, pady=10)
chB7 = Checkbutton(root, text='Коротковолновой ИК2 (B7)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB7)
chB7.grid(column=1, row=7, padx=10, pady=10)
chB8 = Checkbutton(root, text='Панхроматический (B8)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB8)
chB8.grid(column=1, row=8, padx=10, pady=10)
chB9 = Checkbutton(root, text='Облака (B9)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB9)
chB9.grid(column=1, row=9, padx=10, pady=10)
chB10 = Checkbutton(root, text='Тепловой 1 (B10)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB10)
chB10.grid(column=1, row=10, padx=10, pady=10)
chB11 = Checkbutton(root, text='Тепловой 2 (B11)', bg="white", relief="ridge", fg="black", bd=8, font=("Times", 12), width=25, variable=ichB11)
chB11.grid(column=1, row=11, padx=10, pady=10)

# Настройка обработки выбора чекбокса
chB1.bind('<Button-1>', get_b1)
chB2.bind('<Button-1>', get_b2)
chB3.bind('<Button-1>', get_b3)
chB4.bind('<Button-1>', get_b4)
chB5.bind('<Button-1>', get_b5)
chB6.bind('<Button-1>', get_b6)
chB7.bind('<Button-1>', get_b7)
chB8.bind('<Button-1>', get_b8)
chB9.bind('<Button-1>', get_b9)
chB10.bind('<Button-1>', get_b10)
chB11.bind('<Button-1>', get_b11)
# chB7.bind('<Button-7>', get_b7)
# chB8.bind('<Button-8>', get_b8)
# chB9.bind('<Button-9>', get_b9)
# chB10.bind('<Button-10>', get_b10)
# chB11.bind('<Button-11>', get_b11)

chB1.grid_remove()
chB2.grid_remove()
chB3.grid_remove()
chB4.grid_remove()
chB5.grid_remove()
chB6.grid_remove()
chB7.grid_remove()
chB8.grid_remove()
chB9.grid_remove()
chB10.grid_remove()
chB11.grid_remove()

######## Позиция всех кнопок и полей ввода

#root.mainloop()
tk.mainloop()

cv2.waitKey(0)
cv2.destroyAllWindows()



